<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class DnaGiftsControllerTest extends JControllerForm
{
    protected $view_list = 'tests';
}